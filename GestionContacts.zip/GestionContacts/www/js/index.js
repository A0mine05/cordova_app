const contacts = [];

function ajouterContact() {
    const nom = document.getElementById("nom").value;
    const prenom = document.getElementById("prenom").value;
    const numero = document.getElementById("numero").value;

    if (nom && prenom && numero && !isNaN(numero)) {
        const contact = { nom, prenom, numero };
        contacts.push(contact);
        afficherContacts();
        clearInputs();
    } else {
        alert("Tous les champs sont obligatoires et le numéro de téléphone doit être un nombre.");
    }
}

function supprimerContact() {
    const index = document.getElementById("indexASupprimer").value - 1;
    if (index >= 0 && index < contacts.length) {
        contacts.splice(index, 1);
        afficherContacts();
    } else {
        alert("Index invalide");
    }
}

function modifierContact() {
    const index = document.getElementById("indexAModifier").value - 1;
    const nom = document.getElementById("nomModifier").value;
    const prenom = document.getElementById("prenomModifier").value;
    const numero = document.getElementById("numeroModifier").value;

    if (index >= 0 && index < contacts.length) {
        if (nom && prenom && numero && !isNaN(numero)) {
            contacts[index] = { nom, prenom, numero };
            afficherContacts();
            clearModifyInputs();
        } else {
            alert("Tous les champs sont obligatoires et le numéro de téléphone doit être un nombre.");
        }
    } else {
        alert("Index invalide");
    }
}

function afficherContacts() {
    const ul = document.getElementById("listeContacts");
    ul.innerHTML = "";
    contacts.forEach((contact, index) => {
        const li = document.createElement("li");
        li.textContent = `${index + 1}: ${contact.nom} ${contact.prenom} - ${contact.numero}`;
        ul.appendChild(li);
    });
}

function clearInputs() {
    document.getElementById("nom").value = "";
    document.getElementById("prenom").value = "";
    document.getElementById("numero").value = "";
}

function clearModifyInputs() {
    document.getElementById("nomModifier").value = "";
    document.getElementById("prenomModifier").value = "";
    document.getElementById("numeroModifier").value = "";
}
